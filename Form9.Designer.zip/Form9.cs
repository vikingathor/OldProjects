﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        private List<Böcker> böcker = new List<Böcker>(); //Vår lista med böcker som lagrar dem som sedan ska skickas //

        

        public Form1()
        {
            InitializeComponent();
            
        }

        private async Task KopplasTillCentralDatornAsync() //Asynkron metod async och wait Används som sagt för nätverksoperationer vilket gör programmet och dess aplikationer mycket mer responiva //
        {
            TcpClient VårKlient = new TcpClient();
            VårKlient.NoDelay = true;
            await VårKlient.ConnectAsync("127.0.0.1", 12345); //Vårt Portnummer och IPAdress då 127.0.0.1 alltid är Själva datorn vet vi att serverportern är 12345//
        }

        private async void ButtonConnect_Click(object sender, EventArgs e) //Knappen trycks för att få en koppling med Centraldatorn programmet //
        {
            try
            {
                await KopplasTillCentralDatornAsync(); //Klassen som sagt skappar en TcpClient och ansluter då till servern vilket är centraldatorn med hjälp av connectasync //
                ButtonConnect.BackColor = Color.Green;//Om kopplingen till Servern/Centraldatorn Lyckas kommer knappen bli grön //
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Något fel hände med kopplingen till centraldatorn: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); //Felhantering om kopplingen till centraldatorn misslyckas //
            }
        }

        private void LaddaBöcker_Click(object sender, EventArgs e) //klassen används för att ta fram en fil som innehåler böckerna //
        {
            OpenFileDialog öpenFilDialog = new OpenFileDialog(); //OpenfileDialog hjälper oss att kunna välja text filen //
            try
            {
                öpenFilDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Hämtade filer"; //Genväg till Hämtade filer eftersom textfilen är där för mig //
                if (öpenFilDialog.ShowDialog() == DialogResult.OK)
                {
                    string filvägen = öpenFilDialog.FileName;
                    LaddasBöckernaFrånFile(filvägen);
                    UpdateraListanMedBöcker();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ett fel inträffade då laddningen av böcker inträffade: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LaddasBöckernaFrånFile(string filväg) //Hjälper oss separera och dela in böckerna i text filen //
        {
            string[] Lines = File.ReadAllLines(filväg, Encoding.UTF8);

            foreach (string Line in Lines)
            {
                string[] Delar = Line.Split(new[] { "###" }, StringSplitOptions.None);
                if (Delar.Length >= 4)
                {
                    Böcker bok = new Böcker
                    {
                        Titeln = Delar[0],
                        Skribent = Delar[1],
                        Genre = Delar[2],
                        Accesssible = bool.Parse(Delar[3])
                    };
                    böcker.Add(bok);
                }
            }
            UpdateraListanMedBöcker();
        }

        private void UpdateraListanMedBöcker()
        {
            ListOfBöcker.Items.Clear();

            foreach (var bok in böcker)
            {
                ListOfBöcker.Items.Add(bok);
            }
        }

        private async void SendCentraldatorn_Click(object sender, EventArgs e) //Skickar dem valda böckerna till Centraldatorn //
        {
            try
            {
                await SkickarvaldaBöckerTillCentralDatorn();
                UpdateraListanMedBöcker();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ett fel inträffade vid sändning av böcker till centraldatorn: {ex.Message}", "Error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async Task SkickarvaldaBöckerTillCentralDatorn() //Klassen som innehåler dem valda böckerna och skickar sedan dem till Centraldatorn //
        {
            using (TcpClient VåranKlient = new TcpClient()) //Använder TcpClient och Networkstream för att skicka data då enanslutning etablerats//
            {
                IPAddress adress = IPAddress.Parse("127.0.0.1");

                await VåranKlient.ConnectAsync("127.0.0.1", 12345);

                using (NetworkStream Vårnätverksström = VåranKlient.GetStream())
                {
                    foreach (var selectedItem in ListOfBöcker.SelectedItems)
                    {
                        Böcker ValdaBöcker = (Böcker)selectedItem;
                        string StringAvBöcker = ValdaBöcker.ToString();

                        
                        byte[] BufferFörData = Encoding.UTF8.GetBytes(StringAvBöcker); //Konverterar stringen till bytes //

                        
                        byte[] LängdenAvMeddelandet = BitConverter.GetBytes(BufferFörData.Length); //Nu skickas längden av meddelandet //
                        await Vårnätverksström.WriteAsync(LängdenAvMeddelandet, 0, LängdenAvMeddelandet.Length);

                        
                        await Vårnätverksström.WriteAsync(BufferFörData, 0, BufferFörData.Length); //Medans den verkliga datan skickas här //
                        
                        

                        Console.WriteLine($"Sending: {ValdaBöcker}");
                    }
                }
            }
        }

    }

    public class Böcker //Bok klasssen där våra egenskaper för böckrna skapas //
    {
        public string Titeln { get; set; }
        public string Skribent { get; set; }
        public string Genre { get; set; }
        public bool Accesssible { get; set; }

        public override string ToString()
        {
            return $"{Titeln} av {Skribent}, Typ: {Genre}, Accesible: {Accesssible}"; //De egenskaperna som Listan innehåler //
        }
    }

    

}
