﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonConnect = new System.Windows.Forms.Button();
            this.ListOfBöcker = new System.Windows.Forms.ListBox();
            this.SendCentraldatorn = new System.Windows.Forms.Button();
            this.LaddaBöcker = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ButtonConnect
            // 
            this.ButtonConnect.Location = new System.Drawing.Point(72, 12);
            this.ButtonConnect.Name = "ButtonConnect";
            this.ButtonConnect.Size = new System.Drawing.Size(75, 23);
            this.ButtonConnect.TabIndex = 0;
            this.ButtonConnect.Text = "CentraldConnect";
            this.ButtonConnect.UseVisualStyleBackColor = true;
            this.ButtonConnect.Click += new System.EventHandler(this.ButtonConnect_Click);
            // 
            // ListOfBöcker
            // 
            this.ListOfBöcker.FormattingEnabled = true;
            this.ListOfBöcker.ItemHeight = 16;
            this.ListOfBöcker.Location = new System.Drawing.Point(153, 1);
            this.ListOfBöcker.Name = "ListOfBöcker";
            this.ListOfBöcker.Size = new System.Drawing.Size(277, 260);
            this.ListOfBöcker.TabIndex = 1;
            // 
            // SendCentraldatorn
            // 
            this.SendCentraldatorn.Location = new System.Drawing.Point(72, 70);
            this.SendCentraldatorn.Name = "SendCentraldatorn";
            this.SendCentraldatorn.Size = new System.Drawing.Size(75, 23);
            this.SendCentraldatorn.TabIndex = 2;
            this.SendCentraldatorn.Text = "SkickaTillCentralDator";
            this.SendCentraldatorn.UseVisualStyleBackColor = true;
            this.SendCentraldatorn.Click += new System.EventHandler(this.SendCentraldatorn_Click);
            // 
            // LaddaBöcker
            // 
            this.LaddaBöcker.Location = new System.Drawing.Point(72, 41);
            this.LaddaBöcker.Name = "LaddaBöcker";
            this.LaddaBöcker.Size = new System.Drawing.Size(75, 23);
            this.LaddaBöcker.TabIndex = 3;
            this.LaddaBöcker.Text = "LaddaBöcker";
            this.LaddaBöcker.UseVisualStyleBackColor = true;
            this.LaddaBöcker.Click += new System.EventHandler(this.LaddaBöcker_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LaddaBöcker);
            this.Controls.Add(this.SendCentraldatorn);
            this.Controls.Add(this.ListOfBöcker);
            this.Controls.Add(this.ButtonConnect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ButtonConnect;
        private System.Windows.Forms.ListBox ListOfBöcker;
        private System.Windows.Forms.Button SendCentraldatorn;
        private System.Windows.Forms.Button LaddaBöcker;
    }
}

